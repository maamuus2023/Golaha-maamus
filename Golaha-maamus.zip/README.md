# Golaha Maamus

Mashruucan waxaa loo sameeyey sidii is-dhexgal dhallinyarada iyo wacyigelin looga sameeyo balwadaha iyo dhibaatooyinkooda. Waxa uu kor u qaadaa fursadaha is-beddelka togan ee dhallinyarada Soomaaliyeed.

## Ujeedada
- Kor u qaad wacyiga dhalinyarada
- Ka hortag balwadaha
- Is-dhexgal bulsho

## Teknoolajiyadda la isticmaalay
- HTML5
- CSS3
- GitHub + Vercel (deployment)

## Website-ka
[golaha-maamus.vercel.app](https://golaha-maamus.vercel.app)